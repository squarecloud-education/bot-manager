import time

while True:
    print("Tamo na Square tamo na Square")
    time.sleep(30)